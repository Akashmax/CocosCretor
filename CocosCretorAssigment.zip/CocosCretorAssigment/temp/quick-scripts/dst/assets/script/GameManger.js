
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/GameManger.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '60988nJquhK6I53ZDvsPJ8H', 'GameManger');
// script/GameManger.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameManger = /** @class */ (function (_super) {
    __extends(GameManger, _super);
    function GameManger() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.CardPrefabs = null;
        _this.GameScetion = null;
        _this.NextWrap = null;
        _this.PickColor = [];
        _this.MinNum = 0;
        _this.MaxNum = 0;
        _this.howmanyeachcard = 0;
        _this.BAckCArd = null;
        _this.Highlightimg = null;
        _this.blockTransp = null;
        _this.Leveltext = null;
        _this.LevelDone = null;
        _this.StoreAllCard = [];
        _this.NextCount = 1;
        _this.firstClick = null;
        _this.SecondClick = null;
        _this.callback = null;
        _this.FinalCountAllCard = 0;
        return _this;
    }
    GameManger_1 = GameManger;
    GameManger.prototype.onLoad = function () {
        GameManger_1.instance = this;
    };
    GameManger.prototype.start = function () {
        // this.PickColor = this.PickRandomColor();
        this.GetupCard();
        this.ShuffleArr(this.StoreAllCard);
        this.SetupCard();
    };
    GameManger.prototype.GetupCard = function () {
        var getrandom = this.PickThreeRandomNum();
        for (var i = 0; i < this.PickColor.length; i++) {
            for (var j = 0; j < this.howmanyeachcard; j++) {
                var card = cc.instantiate(this.CardPrefabs);
                card.children[2].getComponent(cc.Label).string = getrandom[i];
                card.children[1].getComponent(cc.Label).string = getrandom[i];
                card.children[0].color = this.PickColor[i];
                //  card.parent = this.GameScetion.children[i];
                card.setSiblingIndex(j);
                this.StoreAllCard.push(card);
            }
        }
    };
    GameManger.prototype.SetupCard = function () {
        var SequenceCount = 0;
        var PosY = 0;
        for (var i = 0; i < this.PickColor.length; i++) {
            PosY = 0;
            for (var j = 0; j < this.howmanyeachcard; j++) {
                this.StoreAllCard[SequenceCount].parent = this.GameScetion.children[i];
                this.StoreAllCard[SequenceCount].y = PosY;
                var cardbtn = this.StoreAllCard[SequenceCount].addComponent(cc.Button);
                cardbtn.getComponent(cc.Button).node.on("click", this.ClickCard, false);
                PosY -= 40;
                SequenceCount++;
            }
        }
        for (var k = 0; k < this.GameScetion.childrenCount; k++) {
            var cardparentbtn = this.GameScetion.children[k].addComponent(cc.Button);
            cardparentbtn.node.on("click", this.ClickCard, false);
        }
        GameManger_1.instance.lastBtnActive();
    };
    GameManger.prototype.ClickCard = function (event) {
        var curnode = event.node;
        if (GameManger_1.instance.firstClick != null && GameManger_1.instance.SecondClick == null) {
            GameManger_1.instance.SecondClick = curnode;
            var ChildCount = 0;
            var Getfirstindex = GameManger_1.instance.firstClick.parent.getSiblingIndex();
            var GetSecondindex = GameManger_1.instance.SecondClick.parent.getSiblingIndex();
            if (GameManger_1.instance.SecondClick.name == "Block" || GetSecondindex != Getfirstindex) {
                if (GameManger_1.instance.SecondClick.name == "Block") {
                    GameManger_1.instance.firstClick.parent = GameManger_1.instance.SecondClick;
                }
                else {
                    GameManger_1.instance.firstClick.parent = GameManger_1.instance.SecondClick.parent;
                    ChildCount = GameManger_1.instance.firstClick.parent.childrenCount;
                }
                var offsetY = (ChildCount == 0 ? 0 : (ChildCount - 1) * -40);
                GameManger_1.instance.MoveCard(GameManger_1.instance.firstClick, cc.v2(0, offsetY));
            }
            else {
                GameManger_1.instance.SecondClick = null;
            }
        }
        else {
            if (GameManger_1.instance.firstClick == null && curnode.name != "Block") {
                GameManger_1.instance.firstClick = curnode;
                GameManger_1.instance.firstClick.getComponent(cc.Sprite).spriteFrame = GameManger_1.instance.Highlightimg;
            }
        }
        clearTimeout(GameManger_1.instance.callback);
        GameManger_1.instance.lastBtnActive();
    };
    GameManger.prototype.MoveCard = function (currnode, secondnode) {
        GameManger_1.instance.firstClick.getComponent(cc.Sprite).spriteFrame = GameManger_1.instance.blockTransp;
        cc.tween(currnode)
            .to(0.2, { position: cc.v2(secondnode.x, secondnode.y) })
            .start();
        GameManger_1.instance.callback = function () {
            GameManger_1.instance.firstClick = null;
            GameManger_1.instance.SecondClick = null;
            GameManger_1.instance.MatchCard(currnode);
        };
        setTimeout(GameManger_1.instance.callback, 200);
    };
    GameManger.prototype.MatchCard = function (currnode) {
        var _this = this;
        if (currnode.parent.childrenCount < this.howmanyeachcard) {
            return;
        }
        var temp = [];
        for (var i = 0; i < currnode.parent.childrenCount; i++) {
            temp.push(parseInt(currnode.parent.children[i].children[1].getComponent(cc.Label).string));
        }
        var IsAllsamevalue = temp.every(function (a) { return a === temp[0]; });
        if (IsAllsamevalue) {
            var _loop_1 = function (i) {
                setTimeout(function () {
                    var flipnode = currnode.parent.children[i];
                    var tween = cc.tween(flipnode)
                        .to(0.5 * i, { y: flipnode.y < -1 ? flipnode.y + (i * 25) : 0, scaleX: -1 })
                        .start();
                    flipnode.children[3].active = true;
                    flipnode.removeComponent(cc.Button);
                    currnode.parent.removeComponent(cc.Button);
                }, (i * 100));
            };
            for (var i = 0; i < currnode.parent.childrenCount; i++) {
                _loop_1(i);
            }
            this.FinalCountAllCard++;
            this.scheduleOnce(function () {
                if (_this.FinalCountAllCard == _this.PickColor.length) {
                    _this.NextWrap.active = true;
                    _this.LevelDone.string = "LEVEL " + _this.NextCount + " COMPLETED";
                }
            }, 1.5);
        }
    };
    GameManger.prototype.HighLightCard = function (currnode) {
        cc.tween(currnode)
            .to(0.5, { position: cc.v2(currnode.x, currnode.y - 50), angle: 5 })
            .to(0.6, { scale: 1.1, angle: -5 })
            .to(0.5, { scale: 1, angle: 0 })
            .start();
    };
    GameManger.prototype.NextBtn = function () {
        this.NextCount++;
        this.Leveltext.string = "Level - " + this.NextCount;
        this.NextWrap.active = false;
        this.destroyCard();
        this.GetupCard();
        this.ShuffleArr(this.StoreAllCard);
        this.SetupCard();
    };
    GameManger.prototype.destroyCard = function () {
        //Destroy node
        for (var i = 0; i < this.GameScetion.childrenCount; i++) {
            if (this.GameScetion.children[i].childrenCount != 0) {
                for (var j = 0; j < this.GameScetion.children[i].childrenCount; j++) {
                    (this.GameScetion.children[i].children[j]).destroy();
                }
                this.GameScetion.children[i].removeAllChildren();
            }
        }
        //Reset value
        this.StoreAllCard = [];
        this.FinalCountAllCard = 0;
        this.callback = null;
        GameManger_1.instance.firstClick = null;
        GameManger_1.instance.SecondClick = null;
    };
    GameManger.prototype.lastBtnActive = function () {
        for (var i = 0; i < this.GameScetion.childrenCount; i++) {
            if (this.GameScetion.children[i].childrenCount != 0 && this.GameScetion.children[i].getComponent(cc.Button)) {
                this.GameScetion.children[i].getComponent(cc.Button).interactable = false;
                for (var j = 0; j < this.GameScetion.children[i].childrenCount; j++) {
                    if (j != this.GameScetion.children[i].childrenCount - 1) {
                        this.GameScetion.children[i].children[j].getComponent(cc.Button).interactable = false;
                    }
                    else {
                        this.GameScetion.children[i].children[j].getComponent(cc.Button).interactable = true;
                    }
                }
            }
            else {
                if (this.GameScetion.children[i].getComponent(cc.Button)) {
                    this.GameScetion.children[i].getComponent(cc.Button).interactable = true;
                }
            }
        }
    };
    GameManger.prototype.PickThreeRandomNum = function () {
        var rand = [];
        while (rand.length < this.PickColor.length) {
            var num = Math.floor(Math.random() * (this.MaxNum - this.MinNum) + this.MinNum);
            if (rand.indexOf(num) == -1) {
                rand.push(num);
            }
        }
        return rand;
    };
    GameManger.prototype.ShuffleArr = function (shuffled) {
        var _a;
        for (var i = shuffled.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * i + 1);
            _a = [shuffled[j], shuffled[i]], shuffled[i] = _a[0], shuffled[j] = _a[1];
        }
        return shuffled;
    };
    GameManger.prototype.PickRandomColor = function () {
        //Genrate three light color
        var pickcolor = [];
        for (var i = 0; i < this.PickColor.length; i++) {
            var Genratecolor = cc.color((1 + Math.random()) * 256 / 2, (1 + Math.random()) * 256 / 2, (1 + Math.random()) * 256 / 2);
            pickcolor.push(Genratecolor);
        }
        return pickcolor;
    };
    var GameManger_1;
    __decorate([
        property(cc.Prefab)
    ], GameManger.prototype, "CardPrefabs", void 0);
    __decorate([
        property(cc.Node)
    ], GameManger.prototype, "GameScetion", void 0);
    __decorate([
        property(cc.Node)
    ], GameManger.prototype, "NextWrap", void 0);
    __decorate([
        property(cc.Color)
    ], GameManger.prototype, "PickColor", void 0);
    __decorate([
        property(cc.Integer)
    ], GameManger.prototype, "MinNum", void 0);
    __decorate([
        property(cc.Integer)
    ], GameManger.prototype, "MaxNum", void 0);
    __decorate([
        property(cc.Integer)
    ], GameManger.prototype, "howmanyeachcard", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], GameManger.prototype, "BAckCArd", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], GameManger.prototype, "Highlightimg", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], GameManger.prototype, "blockTransp", void 0);
    __decorate([
        property(cc.Label)
    ], GameManger.prototype, "Leveltext", void 0);
    __decorate([
        property(cc.Label)
    ], GameManger.prototype, "LevelDone", void 0);
    GameManger = GameManger_1 = __decorate([
        ccclass
    ], GameManger);
    return GameManger;
}(cc.Component));
exports.default = GameManger;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxHYW1lTWFuZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBcVJDO1FBaFJHLGlCQUFXLEdBQWMsSUFBSSxDQUFDO1FBRzlCLGlCQUFXLEdBQVksSUFBSSxDQUFDO1FBRzVCLGNBQVEsR0FBWSxJQUFJLENBQUM7UUFHekIsZUFBUyxHQUFlLEVBQUUsQ0FBQztRQUczQixZQUFNLEdBQUcsQ0FBQyxDQUFDO1FBR1gsWUFBTSxHQUFHLENBQUMsQ0FBQztRQUdYLHFCQUFlLEdBQUcsQ0FBQyxDQUFDO1FBR3BCLGNBQVEsR0FBbUIsSUFBSSxDQUFDO1FBR2hDLGtCQUFZLEdBQW1CLElBQUksQ0FBQztRQUdwQyxpQkFBVyxHQUFtQixJQUFJLENBQUM7UUFHbkMsZUFBUyxHQUFhLElBQUksQ0FBQztRQUczQixlQUFTLEdBQWEsSUFBSSxDQUFDO1FBRTNCLGtCQUFZLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLGVBQVMsR0FBRyxDQUFDLENBQUM7UUFDZCxnQkFBVSxHQUFRLElBQUksQ0FBQztRQUN2QixpQkFBVyxHQUFRLElBQUksQ0FBQztRQUN4QixjQUFRLEdBQVEsSUFBSSxDQUFDO1FBQ3JCLHVCQUFpQixHQUFHLENBQUMsQ0FBQzs7SUF3TzFCLENBQUM7bUJBclJvQixVQUFVO0lBZ0QzQiwyQkFBTSxHQUFOO1FBQ0ksWUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7SUFDL0IsQ0FBQztJQUVELDBCQUFLLEdBQUw7UUFDSSwyQ0FBMkM7UUFDM0MsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQsOEJBQVMsR0FBVDtRQUVJLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzFDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUU1QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDM0MsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzVDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDM0MsK0NBQStDO2dCQUMvQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUV4QixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNoQztTQUVKO0lBQ0wsQ0FBQztJQUVELDhCQUFTLEdBQVQ7UUFDSSxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUM7UUFDdEIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzVDLElBQUksR0FBRyxDQUFDLENBQUM7WUFFVCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZFLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztnQkFDMUMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN2RSxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUN4RSxJQUFJLElBQUksRUFBRSxDQUFDO2dCQUNYLGFBQWEsRUFBRSxDQUFDO2FBQ25CO1NBQ0o7UUFFRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDckQsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN6RSxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQTtTQUN4RDtRQUNELFlBQVUsQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDeEMsQ0FBQztJQUVELDhCQUFTLEdBQVQsVUFBVSxLQUFLO1FBQ1gsSUFBSSxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztRQUN6QixJQUFJLFlBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxZQUFVLENBQUMsUUFBUSxDQUFDLFdBQVcsSUFBSSxJQUFJLEVBQUU7WUFDbkYsWUFBVSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDO1lBQzFDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztZQUNuQixJQUFJLGFBQWEsR0FBRyxZQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDNUUsSUFBSSxjQUFjLEdBQUcsWUFBVSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBRTlFLElBQUksWUFBVSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLE9BQU8sSUFBSSxjQUFjLElBQUksYUFBYSxFQUFFO2dCQUdwRixJQUFJLFlBQVUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksSUFBSSxPQUFPLEVBQUU7b0JBQ2pELFlBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxZQUFVLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQztpQkFFM0U7cUJBQU07b0JBQ0gsWUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLFlBQVUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQztvQkFDL0UsVUFBVSxHQUFHLFlBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7aUJBQ3BFO2dCQUNELElBQUksT0FBTyxHQUFHLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFBO2dCQUM1RCxZQUFVLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxZQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO2FBRW5GO2lCQUFNO2dCQUNILFlBQVUsQ0FBQyxRQUFRLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQzthQUMxQztTQUdKO2FBQU07WUFDSCxJQUFJLFlBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxPQUFPLENBQUMsSUFBSSxJQUFJLE9BQU8sRUFBRTtnQkFDbkUsWUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDO2dCQUN6QyxZQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsR0FBRyxZQUFVLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQzthQUN6RztTQUNKO1FBQ0QsWUFBWSxDQUFDLFlBQVUsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0MsWUFBVSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN4QyxDQUFDO0lBRUQsNkJBQVEsR0FBUixVQUFTLFFBQVEsRUFBRSxVQUFVO1FBQ3pCLFlBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxHQUFHLFlBQVUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDO1FBQ3JHLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO2FBQ2IsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7YUFDeEQsS0FBSyxFQUFFLENBQUE7UUFDWixZQUFVLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRztZQUUzQixZQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDdEMsWUFBVSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO1lBQ3ZDLFlBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVDLENBQUMsQ0FBQztRQUNGLFVBQVUsQ0FBQyxZQUFVLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUVsRCxDQUFDO0lBRUQsOEJBQVMsR0FBVCxVQUFVLFFBQVE7UUFBbEIsaUJBa0NDO1FBaENHLElBQUksUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUFFLE9BQU07U0FBRTtRQUdwRSxJQUFJLElBQUksR0FBRyxFQUFFLENBQUE7UUFDYixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDcEQsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztTQUM5RjtRQUNELElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFiLENBQWEsQ0FBQyxDQUFBO1FBRW5ELElBQUksY0FBYyxFQUFFO29DQUNQLENBQUM7Z0JBQ04sVUFBVSxDQUFDO29CQUNQLElBQUksUUFBUSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMzQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQzt5QkFDekIsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO3lCQUMzRSxLQUFLLEVBQUUsQ0FBQztvQkFDYixRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7b0JBQ25DLFFBQVEsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNwQyxRQUFRLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQy9DLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDOztZQVRsQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsQ0FBQyxFQUFFO3dCQUE3QyxDQUFDO2FBV1Q7WUFDRCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUN6QixJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNkLElBQUksS0FBSSxDQUFDLGlCQUFpQixJQUFJLEtBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFO29CQUNqRCxLQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7b0JBQzVCLEtBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLFFBQVEsR0FBRyxLQUFJLENBQUMsU0FBUyxHQUFHLFlBQVksQ0FBQTtpQkFDbkU7WUFDTCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FHWDtJQUNMLENBQUM7SUFFRCxrQ0FBYSxHQUFiLFVBQWMsUUFBUTtRQUNsQixFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQzthQUNiLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDO2FBQ25FLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO2FBQ2xDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQzthQUMvQixLQUFLLEVBQUUsQ0FBQTtJQUNoQixDQUFDO0lBRUQsNEJBQU8sR0FBUDtRQUVJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUNwRCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDN0IsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNuQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7SUFFckIsQ0FBQztJQUVELGdDQUFXLEdBQVg7UUFFSSxjQUFjO1FBQ2QsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3JELElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxJQUFJLENBQUMsRUFBRTtnQkFDakQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDakUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztpQkFDeEQ7Z0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzthQUNwRDtTQUNKO1FBQ0QsYUFBYTtRQUNiLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDckIsWUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3RDLFlBQVUsQ0FBQyxRQUFRLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztJQUMzQyxDQUFDO0lBRUQsa0NBQWEsR0FBYjtRQUNJLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNyRCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDekcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO2dCQUMxRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUNqRSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxFQUFFO3dCQUNyRCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO3FCQUN6Rjt5QkFBTTt3QkFDSCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO3FCQUN4RjtpQkFFSjthQUNKO2lCQUFNO2dCQUNILElBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBQztvQkFDcEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO2lCQUM1RTthQUVKO1NBQ0o7SUFDTCxDQUFDO0lBRUQsdUNBQWtCLEdBQWxCO1FBQ0ksSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2QsT0FBTyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFO1lBQ3hDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2hGLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRTtnQkFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTthQUNqQjtTQUNKO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVELCtCQUFVLEdBQVYsVUFBVyxRQUFROztRQUNmLEtBQUssSUFBSSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMxQyxJQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDNUMsS0FBNkIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQXRELFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBQSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBQSxDQUErQjtTQUMzRDtRQUNELE9BQU8sUUFBUSxDQUFDO0lBRXBCLENBQUM7SUFFRCxvQ0FBZSxHQUFmO1FBQ0ksMkJBQTJCO1FBQzNCLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQztRQUNuQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDNUMsSUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzNILFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDaEM7UUFDRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDOztJQS9RRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO21EQUNVO0lBRzlCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7bURBQ1U7SUFHNUI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztnREFDTztJQUd6QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO2lEQUNRO0lBRzNCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUM7OENBQ1Y7SUFHWDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDOzhDQUNWO0lBR1g7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQzt1REFDRDtJQUdwQjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDO2dEQUNPO0lBR2hDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUM7b0RBQ1c7SUFHcEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQzttREFDVTtJQUduQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO2lEQUNRO0lBRzNCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7aURBQ1E7SUF0Q1YsVUFBVTtRQUQ5QixPQUFPO09BQ2EsVUFBVSxDQXFSOUI7SUFBRCxpQkFBQztDQXJSRCxBQXFSQyxDQXJSdUMsRUFBRSxDQUFDLFNBQVMsR0FxUm5EO2tCQXJSb0IsVUFBVSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBHYW1lTWFuZ2VyIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBzdGF0aWMgaW5zdGFuY2U6IEdhbWVNYW5nZXJcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxyXG4gICAgQ2FyZFByZWZhYnM6IGNjLlByZWZhYiA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBHYW1lU2NldGlvbjogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBOZXh0V3JhcDogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLkNvbG9yKVxyXG4gICAgUGlja0NvbG9yOiBjYy5Db2xvcltdID0gW107XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLkludGVnZXIpXHJcbiAgICBNaW5OdW0gPSAwO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5JbnRlZ2VyKVxyXG4gICAgTWF4TnVtID0gMDtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuSW50ZWdlcilcclxuICAgIGhvd21hbnllYWNoY2FyZCA9IDA7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLlNwcml0ZUZyYW1lKVxyXG4gICAgQkFja0NBcmQ6IGNjLlNwcml0ZUZyYW1lID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuU3ByaXRlRnJhbWUpXHJcbiAgICBIaWdobGlnaHRpbWc6IGNjLlNwcml0ZUZyYW1lID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuU3ByaXRlRnJhbWUpXHJcbiAgICBibG9ja1RyYW5zcDogY2MuU3ByaXRlRnJhbWUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcclxuICAgIExldmVsdGV4dDogY2MuTGFiZWwgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcclxuICAgIExldmVsRG9uZTogY2MuTGFiZWwgPSBudWxsO1xyXG5cclxuICAgIFN0b3JlQWxsQ2FyZCA9IFtdO1xyXG4gICAgTmV4dENvdW50ID0gMTtcclxuICAgIGZpcnN0Q2xpY2s6IGFueSA9IG51bGw7XHJcbiAgICBTZWNvbmRDbGljazogYW55ID0gbnVsbDtcclxuICAgIGNhbGxiYWNrOiBhbnkgPSBudWxsO1xyXG4gICAgRmluYWxDb3VudEFsbENhcmQgPSAwO1xyXG5cclxuXHJcbiAgICBvbkxvYWQoKSB7XHJcbiAgICAgICAgR2FtZU1hbmdlci5pbnN0YW5jZSA9IHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICAgICAgLy8gdGhpcy5QaWNrQ29sb3IgPSB0aGlzLlBpY2tSYW5kb21Db2xvcigpO1xyXG4gICAgICAgIHRoaXMuR2V0dXBDYXJkKCk7XHJcbiAgICAgICAgdGhpcy5TaHVmZmxlQXJyKHRoaXMuU3RvcmVBbGxDYXJkKTtcclxuICAgICAgICB0aGlzLlNldHVwQ2FyZCgpO1xyXG4gICAgfVxyXG5cclxuICAgIEdldHVwQ2FyZCgpIHtcclxuXHJcbiAgICAgICAgdmFyIGdldHJhbmRvbSA9IHRoaXMuUGlja1RocmVlUmFuZG9tTnVtKCk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLlBpY2tDb2xvci5sZW5ndGg7IGkrKykge1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCB0aGlzLmhvd21hbnllYWNoY2FyZDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgY2FyZCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQ2FyZFByZWZhYnMpO1xyXG4gICAgICAgICAgICAgICAgY2FyZC5jaGlsZHJlblsyXS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IGdldHJhbmRvbVtpXTtcclxuICAgICAgICAgICAgICAgIGNhcmQuY2hpbGRyZW5bMV0uZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBnZXRyYW5kb21baV07XHJcbiAgICAgICAgICAgICAgICBjYXJkLmNoaWxkcmVuWzBdLmNvbG9yID0gdGhpcy5QaWNrQ29sb3JbaV07XHJcbiAgICAgICAgICAgICAgICAvLyAgY2FyZC5wYXJlbnQgPSB0aGlzLkdhbWVTY2V0aW9uLmNoaWxkcmVuW2ldO1xyXG4gICAgICAgICAgICAgICAgY2FyZC5zZXRTaWJsaW5nSW5kZXgoaik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5TdG9yZUFsbENhcmQucHVzaChjYXJkKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgU2V0dXBDYXJkKCkge1xyXG4gICAgICAgIGxldCBTZXF1ZW5jZUNvdW50ID0gMDtcclxuICAgICAgICB2YXIgUG9zWSA9IDA7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLlBpY2tDb2xvci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBQb3NZID0gMDtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgdGhpcy5ob3dtYW55ZWFjaGNhcmQ7IGorKykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5TdG9yZUFsbENhcmRbU2VxdWVuY2VDb3VudF0ucGFyZW50ID0gdGhpcy5HYW1lU2NldGlvbi5jaGlsZHJlbltpXTtcclxuICAgICAgICAgICAgICAgIHRoaXMuU3RvcmVBbGxDYXJkW1NlcXVlbmNlQ291bnRdLnkgPSBQb3NZO1xyXG4gICAgICAgICAgICAgICAgdmFyIGNhcmRidG4gPSB0aGlzLlN0b3JlQWxsQ2FyZFtTZXF1ZW5jZUNvdW50XS5hZGRDb21wb25lbnQoY2MuQnV0dG9uKTtcclxuICAgICAgICAgICAgICAgIGNhcmRidG4uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikubm9kZS5vbihcImNsaWNrXCIsIHRoaXMuQ2xpY2tDYXJkLCBmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICBQb3NZIC09IDQwO1xyXG4gICAgICAgICAgICAgICAgU2VxdWVuY2VDb3VudCsrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IHRoaXMuR2FtZVNjZXRpb24uY2hpbGRyZW5Db3VudDsgaysrKSB7XHJcbiAgICAgICAgICAgIHZhciBjYXJkcGFyZW50YnRuID0gdGhpcy5HYW1lU2NldGlvbi5jaGlsZHJlbltrXS5hZGRDb21wb25lbnQoY2MuQnV0dG9uKTtcclxuICAgICAgICAgICAgY2FyZHBhcmVudGJ0bi5ub2RlLm9uKFwiY2xpY2tcIiwgdGhpcy5DbGlja0NhcmQsIGZhbHNlKVxyXG4gICAgICAgIH1cclxuICAgICAgICBHYW1lTWFuZ2VyLmluc3RhbmNlLmxhc3RCdG5BY3RpdmUoKTtcclxuICAgIH1cclxuXHJcbiAgICBDbGlja0NhcmQoZXZlbnQpIHtcclxuICAgICAgICB2YXIgY3Vybm9kZSA9IGV2ZW50Lm5vZGU7XHJcbiAgICAgICAgaWYgKEdhbWVNYW5nZXIuaW5zdGFuY2UuZmlyc3RDbGljayAhPSBudWxsICYmIEdhbWVNYW5nZXIuaW5zdGFuY2UuU2Vjb25kQ2xpY2sgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBHYW1lTWFuZ2VyLmluc3RhbmNlLlNlY29uZENsaWNrID0gY3Vybm9kZTtcclxuICAgICAgICAgICAgdmFyIENoaWxkQ291bnQgPSAwO1xyXG4gICAgICAgICAgICB2YXIgR2V0Zmlyc3RpbmRleCA9IEdhbWVNYW5nZXIuaW5zdGFuY2UuZmlyc3RDbGljay5wYXJlbnQuZ2V0U2libGluZ0luZGV4KCk7XHJcbiAgICAgICAgICAgIHZhciBHZXRTZWNvbmRpbmRleCA9IEdhbWVNYW5nZXIuaW5zdGFuY2UuU2Vjb25kQ2xpY2sucGFyZW50LmdldFNpYmxpbmdJbmRleCgpO1xyXG5cclxuICAgICAgICAgICAgaWYgKEdhbWVNYW5nZXIuaW5zdGFuY2UuU2Vjb25kQ2xpY2submFtZSA9PSBcIkJsb2NrXCIgfHwgR2V0U2Vjb25kaW5kZXggIT0gR2V0Zmlyc3RpbmRleCkge1xyXG5cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoR2FtZU1hbmdlci5pbnN0YW5jZS5TZWNvbmRDbGljay5uYW1lID09IFwiQmxvY2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIEdhbWVNYW5nZXIuaW5zdGFuY2UuZmlyc3RDbGljay5wYXJlbnQgPSBHYW1lTWFuZ2VyLmluc3RhbmNlLlNlY29uZENsaWNrO1xyXG5cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgR2FtZU1hbmdlci5pbnN0YW5jZS5maXJzdENsaWNrLnBhcmVudCA9IEdhbWVNYW5nZXIuaW5zdGFuY2UuU2Vjb25kQ2xpY2sucGFyZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIENoaWxkQ291bnQgPSBHYW1lTWFuZ2VyLmluc3RhbmNlLmZpcnN0Q2xpY2sucGFyZW50LmNoaWxkcmVuQ291bnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB2YXIgb2Zmc2V0WSA9IChDaGlsZENvdW50ID09IDAgPyAwIDogKENoaWxkQ291bnQgLSAxKSAqIC00MClcclxuICAgICAgICAgICAgICAgIEdhbWVNYW5nZXIuaW5zdGFuY2UuTW92ZUNhcmQoR2FtZU1hbmdlci5pbnN0YW5jZS5maXJzdENsaWNrLCBjYy52MigwLCBvZmZzZXRZKSk7XHJcblxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgR2FtZU1hbmdlci5pbnN0YW5jZS5TZWNvbmRDbGljayA9IG51bGw7XHJcbiAgICAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmIChHYW1lTWFuZ2VyLmluc3RhbmNlLmZpcnN0Q2xpY2sgPT0gbnVsbCAmJiBjdXJub2RlLm5hbWUgIT0gXCJCbG9ja1wiKSB7XHJcbiAgICAgICAgICAgICAgICBHYW1lTWFuZ2VyLmluc3RhbmNlLmZpcnN0Q2xpY2sgPSBjdXJub2RlO1xyXG4gICAgICAgICAgICAgICAgR2FtZU1hbmdlci5pbnN0YW5jZS5maXJzdENsaWNrLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gR2FtZU1hbmdlci5pbnN0YW5jZS5IaWdobGlnaHRpbWc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY2xlYXJUaW1lb3V0KEdhbWVNYW5nZXIuaW5zdGFuY2UuY2FsbGJhY2spO1xyXG4gICAgICAgIEdhbWVNYW5nZXIuaW5zdGFuY2UubGFzdEJ0bkFjdGl2ZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIE1vdmVDYXJkKGN1cnJub2RlLCBzZWNvbmRub2RlKSB7XHJcbiAgICAgICAgR2FtZU1hbmdlci5pbnN0YW5jZS5maXJzdENsaWNrLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gR2FtZU1hbmdlci5pbnN0YW5jZS5ibG9ja1RyYW5zcDtcclxuICAgICAgICBjYy50d2VlbihjdXJybm9kZSlcclxuICAgICAgICAgICAgLnRvKDAuMiwgeyBwb3NpdGlvbjogY2MudjIoc2Vjb25kbm9kZS54LCBzZWNvbmRub2RlLnkpIH0pXHJcbiAgICAgICAgICAgIC5zdGFydCgpXHJcbiAgICAgICAgR2FtZU1hbmdlci5pbnN0YW5jZS5jYWxsYmFjayA9ICgpID0+IHtcclxuXHJcbiAgICAgICAgICAgIEdhbWVNYW5nZXIuaW5zdGFuY2UuZmlyc3RDbGljayA9IG51bGw7XHJcbiAgICAgICAgICAgIEdhbWVNYW5nZXIuaW5zdGFuY2UuU2Vjb25kQ2xpY2sgPSBudWxsO1xyXG4gICAgICAgICAgICBHYW1lTWFuZ2VyLmluc3RhbmNlLk1hdGNoQ2FyZChjdXJybm9kZSk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBzZXRUaW1lb3V0KEdhbWVNYW5nZXIuaW5zdGFuY2UuY2FsbGJhY2ssIDIwMCk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIE1hdGNoQ2FyZChjdXJybm9kZSkge1xyXG5cclxuICAgICAgICBpZiAoY3Vycm5vZGUucGFyZW50LmNoaWxkcmVuQ291bnQgPCB0aGlzLmhvd21hbnllYWNoY2FyZCkgeyByZXR1cm4gfVxyXG5cclxuXHJcbiAgICAgICAgdmFyIHRlbXAgPSBbXVxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY3Vycm5vZGUucGFyZW50LmNoaWxkcmVuQ291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICB0ZW1wLnB1c2gocGFyc2VJbnQoY3Vycm5vZGUucGFyZW50LmNoaWxkcmVuW2ldLmNoaWxkcmVuWzFdLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBJc0FsbHNhbWV2YWx1ZSA9IHRlbXAuZXZlcnkoYSA9PiBhID09PSB0ZW1wWzBdKVxyXG5cclxuICAgICAgICBpZiAoSXNBbGxzYW1ldmFsdWUpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjdXJybm9kZS5wYXJlbnQuY2hpbGRyZW5Db3VudDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZmxpcG5vZGUgPSBjdXJybm9kZS5wYXJlbnQuY2hpbGRyZW5baV07XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHR3ZWVuID0gY2MudHdlZW4oZmxpcG5vZGUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50bygwLjUgKiBpLCB7IHk6IGZsaXBub2RlLnkgPCAtMSA/IGZsaXBub2RlLnkgKyAoaSAqIDI1KSA6IDAsIHNjYWxlWDogLTEgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgZmxpcG5vZGUuY2hpbGRyZW5bM10uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBmbGlwbm9kZS5yZW1vdmVDb21wb25lbnQoY2MuQnV0dG9uKTtcclxuICAgICAgICAgICAgICAgICAgICBjdXJybm9kZS5wYXJlbnQucmVtb3ZlQ29tcG9uZW50KGNjLkJ1dHRvbik7XHJcbiAgICAgICAgICAgICAgICB9LCAoaSAqIDEwMCkpO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLkZpbmFsQ291bnRBbGxDYXJkKys7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLkZpbmFsQ291bnRBbGxDYXJkID09IHRoaXMuUGlja0NvbG9yLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuTmV4dFdyYXAuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLkxldmVsRG9uZS5zdHJpbmcgPSBcIkxFVkVMIFwiICsgdGhpcy5OZXh0Q291bnQgKyBcIiBDT01QTEVURURcIlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCAxLjUpO1xyXG5cclxuXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIEhpZ2hMaWdodENhcmQoY3Vycm5vZGUpIHtcclxuICAgICAgICBjYy50d2VlbihjdXJybm9kZSlcclxuICAgICAgICAgICAgLnRvKDAuNSwgeyBwb3NpdGlvbjogY2MudjIoY3Vycm5vZGUueCwgY3Vycm5vZGUueSAtIDUwKSwgYW5nbGU6IDUgfSlcclxuICAgICAgICAgICAgLnRvKDAuNiwgeyBzY2FsZTogMS4xLCBhbmdsZTogLTUgfSlcclxuICAgICAgICAgICAgLnRvKDAuNSwgeyBzY2FsZTogMSwgYW5nbGU6IDAgfSlcclxuICAgICAgICAgICAgLnN0YXJ0KClcclxuICAgIH1cclxuXHJcbiAgICBOZXh0QnRuKCkge1xyXG5cclxuICAgICAgICB0aGlzLk5leHRDb3VudCsrO1xyXG4gICAgICAgIHRoaXMuTGV2ZWx0ZXh0LnN0cmluZyA9IFwiTGV2ZWwgLSBcIiArIHRoaXMuTmV4dENvdW50O1xyXG4gICAgICAgIHRoaXMuTmV4dFdyYXAuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5kZXN0cm95Q2FyZCgpO1xyXG4gICAgICAgIHRoaXMuR2V0dXBDYXJkKCk7XHJcbiAgICAgICAgdGhpcy5TaHVmZmxlQXJyKHRoaXMuU3RvcmVBbGxDYXJkKTtcclxuICAgICAgICB0aGlzLlNldHVwQ2FyZCgpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBkZXN0cm95Q2FyZCgpIHtcclxuXHJcbiAgICAgICAgLy9EZXN0cm95IG5vZGVcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuR2FtZVNjZXRpb24uY2hpbGRyZW5Db3VudDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLkdhbWVTY2V0aW9uLmNoaWxkcmVuW2ldLmNoaWxkcmVuQ291bnQgIT0gMCkge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCB0aGlzLkdhbWVTY2V0aW9uLmNoaWxkcmVuW2ldLmNoaWxkcmVuQ291bnQ7IGorKykge1xyXG4gICAgICAgICAgICAgICAgICAgICh0aGlzLkdhbWVTY2V0aW9uLmNoaWxkcmVuW2ldLmNoaWxkcmVuW2pdKS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLkdhbWVTY2V0aW9uLmNoaWxkcmVuW2ldLnJlbW92ZUFsbENoaWxkcmVuKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy9SZXNldCB2YWx1ZVxyXG4gICAgICAgIHRoaXMuU3RvcmVBbGxDYXJkID0gW107XHJcbiAgICAgICAgdGhpcy5GaW5hbENvdW50QWxsQ2FyZCA9IDA7XHJcbiAgICAgICAgdGhpcy5jYWxsYmFjayA9IG51bGw7XHJcbiAgICAgICAgR2FtZU1hbmdlci5pbnN0YW5jZS5maXJzdENsaWNrID0gbnVsbDtcclxuICAgICAgICBHYW1lTWFuZ2VyLmluc3RhbmNlLlNlY29uZENsaWNrID0gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICBsYXN0QnRuQWN0aXZlKCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5HYW1lU2NldGlvbi5jaGlsZHJlbkNvdW50OyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuR2FtZVNjZXRpb24uY2hpbGRyZW5baV0uY2hpbGRyZW5Db3VudCAhPSAwICYmIHRoaXMuR2FtZVNjZXRpb24uY2hpbGRyZW5baV0uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuR2FtZVNjZXRpb24uY2hpbGRyZW5baV0uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHRoaXMuR2FtZVNjZXRpb24uY2hpbGRyZW5baV0uY2hpbGRyZW5Db3VudDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGogIT0gdGhpcy5HYW1lU2NldGlvbi5jaGlsZHJlbltpXS5jaGlsZHJlbkNvdW50IC0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkdhbWVTY2V0aW9uLmNoaWxkcmVuW2ldLmNoaWxkcmVuW2pdLmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuR2FtZVNjZXRpb24uY2hpbGRyZW5baV0uY2hpbGRyZW5bal0uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5HYW1lU2NldGlvbi5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKSl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5HYW1lU2NldGlvbi5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBQaWNrVGhyZWVSYW5kb21OdW0oKSB7XHJcbiAgICAgICAgdmFyIHJhbmQgPSBbXTtcclxuICAgICAgICB3aGlsZSAocmFuZC5sZW5ndGggPCB0aGlzLlBpY2tDb2xvci5sZW5ndGgpIHtcclxuICAgICAgICAgICAgdmFyIG51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqICh0aGlzLk1heE51bSAtIHRoaXMuTWluTnVtKSArIHRoaXMuTWluTnVtKTtcclxuICAgICAgICAgICAgaWYgKHJhbmQuaW5kZXhPZihudW0pID09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICByYW5kLnB1c2gobnVtKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByYW5kO1xyXG4gICAgfVxyXG5cclxuICAgIFNodWZmbGVBcnIoc2h1ZmZsZWQpIHtcclxuICAgICAgICBmb3IgKHZhciBpID0gc2h1ZmZsZWQubGVuZ3RoIC0gMTsgaSA+IDA7IGktLSkge1xyXG4gICAgICAgICAgICBjb25zdCBqID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogaSArIDEpO1xyXG4gICAgICAgICAgICBbc2h1ZmZsZWRbaV0sIHNodWZmbGVkW2pdXSA9IFtzaHVmZmxlZFtqXSwgc2h1ZmZsZWRbaV1dO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gc2h1ZmZsZWQ7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIFBpY2tSYW5kb21Db2xvcigpIHtcclxuICAgICAgICAvL0dlbnJhdGUgdGhyZWUgbGlnaHQgY29sb3JcclxuICAgICAgICB2YXIgcGlja2NvbG9yID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLlBpY2tDb2xvci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBHZW5yYXRlY29sb3IgPSBjYy5jb2xvcigoMSArIE1hdGgucmFuZG9tKCkpICogMjU2IC8gMiwgKDEgKyBNYXRoLnJhbmRvbSgpKSAqIDI1NiAvIDIsICgxICsgTWF0aC5yYW5kb20oKSkgKiAyNTYgLyAyKTtcclxuICAgICAgICAgICAgcGlja2NvbG9yLnB1c2goR2VucmF0ZWNvbG9yKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHBpY2tjb2xvcjtcclxuICAgIH1cclxufVxyXG4iXX0=