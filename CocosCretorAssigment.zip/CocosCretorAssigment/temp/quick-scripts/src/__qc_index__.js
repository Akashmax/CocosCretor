
require('./assets/script/GameManger');
require('./assets/script/main');
