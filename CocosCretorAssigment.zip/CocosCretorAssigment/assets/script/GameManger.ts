const { ccclass, property } = cc._decorator;

@ccclass
export default class GameManger extends cc.Component {

    static instance: GameManger

    @property(cc.Prefab)
    CardPrefabs: cc.Prefab = null;

    @property(cc.Node)
    GameScetion: cc.Node = null;

    @property(cc.Node)
    NextWrap: cc.Node = null;

    @property(cc.Color)
    PickColor: cc.Color[] = [];

    @property(cc.Integer)
    MinNum = 0;

    @property(cc.Integer)
    MaxNum = 0;

    @property(cc.Integer)
    howmanyeachcard = 0;

    @property(cc.SpriteFrame)
    BAckCArd: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    Highlightimg: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    blockTransp: cc.SpriteFrame = null;

    @property(cc.Label)
    Leveltext: cc.Label = null;

    @property(cc.Label)
    LevelDone: cc.Label = null;

    StoreAllCard = [];
    NextCount = 1;
    firstClick: any = null;
    SecondClick: any = null;
    callback: any = null;
    FinalCountAllCard = 0;


    onLoad() {
        GameManger.instance = this;
    }

    start() {
        // this.PickColor = this.PickRandomColor();
        this.GetupCard();
        this.ShuffleArr(this.StoreAllCard);
        this.SetupCard();
    }

    GetupCard() {

        var getrandom = this.PickThreeRandomNum();
        for (let i = 0; i < this.PickColor.length; i++) {

            for (let j = 0; j < this.howmanyeachcard; j++) {
                var card = cc.instantiate(this.CardPrefabs);
                card.children[2].getComponent(cc.Label).string = getrandom[i];
                card.children[1].getComponent(cc.Label).string = getrandom[i];
                card.children[0].color = this.PickColor[i];
                //  card.parent = this.GameScetion.children[i];
                card.setSiblingIndex(j);

                this.StoreAllCard.push(card);
            }

        }
    }

    SetupCard() {
        let SequenceCount = 0;
        var PosY = 0;
        for (let i = 0; i < this.PickColor.length; i++) {
            PosY = 0;

            for (let j = 0; j < this.howmanyeachcard; j++) {
                this.StoreAllCard[SequenceCount].parent = this.GameScetion.children[i];
                this.StoreAllCard[SequenceCount].y = PosY;
                var cardbtn = this.StoreAllCard[SequenceCount].addComponent(cc.Button);
                cardbtn.getComponent(cc.Button).node.on("click", this.ClickCard, false);
                PosY -= 40;
                SequenceCount++;
            }
        }

        for (let k = 0; k < this.GameScetion.childrenCount; k++) {
            var cardparentbtn = this.GameScetion.children[k].addComponent(cc.Button);
            cardparentbtn.node.on("click", this.ClickCard, false)
        }
        GameManger.instance.lastBtnActive();
    }

    ClickCard(event) {
        var curnode = event.node;
        if (GameManger.instance.firstClick != null && GameManger.instance.SecondClick == null) {
            GameManger.instance.SecondClick = curnode;
            var ChildCount = 0;
            var Getfirstindex = GameManger.instance.firstClick.parent.getSiblingIndex();
            var GetSecondindex = GameManger.instance.SecondClick.parent.getSiblingIndex();

            if (GameManger.instance.SecondClick.name == "Block" || GetSecondindex != Getfirstindex) {


                if (GameManger.instance.SecondClick.name == "Block") {
                    GameManger.instance.firstClick.parent = GameManger.instance.SecondClick;

                } else {
                    GameManger.instance.firstClick.parent = GameManger.instance.SecondClick.parent;
                    ChildCount = GameManger.instance.firstClick.parent.childrenCount;
                }
                var offsetY = (ChildCount == 0 ? 0 : (ChildCount - 1) * -40)
                GameManger.instance.MoveCard(GameManger.instance.firstClick, cc.v2(0, offsetY));

            } else {
                GameManger.instance.SecondClick = null;
            }


        } else {
            if (GameManger.instance.firstClick == null && curnode.name != "Block") {
                GameManger.instance.firstClick = curnode;
                GameManger.instance.firstClick.getComponent(cc.Sprite).spriteFrame = GameManger.instance.Highlightimg;
            }
        }
        clearTimeout(GameManger.instance.callback);
        GameManger.instance.lastBtnActive();
    }

    MoveCard(currnode, secondnode) {
        GameManger.instance.firstClick.getComponent(cc.Sprite).spriteFrame = GameManger.instance.blockTransp;
        cc.tween(currnode)
            .to(0.2, { position: cc.v2(secondnode.x, secondnode.y) })
            .start()
        GameManger.instance.callback = () => {

            GameManger.instance.firstClick = null;
            GameManger.instance.SecondClick = null;
            GameManger.instance.MatchCard(currnode);
        };
        setTimeout(GameManger.instance.callback, 200);

    }

    MatchCard(currnode) {

        if (currnode.parent.childrenCount < this.howmanyeachcard) { return }


        var temp = []
        for (let i = 0; i < currnode.parent.childrenCount; i++) {
            temp.push(parseInt(currnode.parent.children[i].children[1].getComponent(cc.Label).string));
        }
        var IsAllsamevalue = temp.every(a => a === temp[0])

        if (IsAllsamevalue) {
            for (let i = 0; i < currnode.parent.childrenCount; i++) {
                setTimeout(() => {
                    let flipnode = currnode.parent.children[i];
                    var tween = cc.tween(flipnode)
                        .to(0.5 * i, { y: flipnode.y < -1 ? flipnode.y + (i * 25) : 0, scaleX: -1 })
                        .start();
                    flipnode.children[3].active = true;
                    flipnode.removeComponent(cc.Button);
                    currnode.parent.removeComponent(cc.Button);
                }, (i * 100));

            }
            this.FinalCountAllCard++;
            this.scheduleOnce(() => {
                if (this.FinalCountAllCard == this.PickColor.length) {
                    this.NextWrap.active = true;
                    this.LevelDone.string = "LEVEL " + this.NextCount + " COMPLETED"
                }
            }, 1.5);


        }
    }

    HighLightCard(currnode) {
        cc.tween(currnode)
            .to(0.5, { position: cc.v2(currnode.x, currnode.y - 50), angle: 5 })
            .to(0.6, { scale: 1.1, angle: -5 })
            .to(0.5, { scale: 1, angle: 0 })
            .start()
    }

    NextBtn() {

        this.NextCount++;
        this.Leveltext.string = "Level - " + this.NextCount;
        this.NextWrap.active = false;
        this.destroyCard();
        this.GetupCard();
        this.ShuffleArr(this.StoreAllCard);
        this.SetupCard();

    }

    destroyCard() {

        //Destroy node
        for (let i = 0; i < this.GameScetion.childrenCount; i++) {
            if (this.GameScetion.children[i].childrenCount != 0) {
                for (let j = 0; j < this.GameScetion.children[i].childrenCount; j++) {
                    (this.GameScetion.children[i].children[j]).destroy();
                }
                this.GameScetion.children[i].removeAllChildren();
            }
        }
        //Reset value
        this.StoreAllCard = [];
        this.FinalCountAllCard = 0;
        this.callback = null;
        GameManger.instance.firstClick = null;
        GameManger.instance.SecondClick = null;
    }

    lastBtnActive() {
        for (let i = 0; i < this.GameScetion.childrenCount; i++) {
            if (this.GameScetion.children[i].childrenCount != 0 && this.GameScetion.children[i].getComponent(cc.Button)) {
                this.GameScetion.children[i].getComponent(cc.Button).interactable = false;
                for (let j = 0; j < this.GameScetion.children[i].childrenCount; j++) {
                    if (j != this.GameScetion.children[i].childrenCount - 1) {
                        this.GameScetion.children[i].children[j].getComponent(cc.Button).interactable = false;
                    } else {
                        this.GameScetion.children[i].children[j].getComponent(cc.Button).interactable = true;
                    }

                }
            } else {
                if(this.GameScetion.children[i].getComponent(cc.Button)){
                    this.GameScetion.children[i].getComponent(cc.Button).interactable = true;
                }
               
            }
        }
    }

    PickThreeRandomNum() {
        var rand = [];
        while (rand.length < this.PickColor.length) {
            var num = Math.floor(Math.random() * (this.MaxNum - this.MinNum) + this.MinNum);
            if (rand.indexOf(num) == -1) {
                rand.push(num)
            }
        }
        return rand;
    }

    ShuffleArr(shuffled) {
        for (var i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * i + 1);
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;

    }

    PickRandomColor() {
        //Genrate three light color
        var pickcolor = [];
        for (let i = 0; i < this.PickColor.length; i++) {
            const Genratecolor = cc.color((1 + Math.random()) * 256 / 2, (1 + Math.random()) * 256 / 2, (1 + Math.random()) * 256 / 2);
            pickcolor.push(Genratecolor);
        }
        return pickcolor;
    }
}
