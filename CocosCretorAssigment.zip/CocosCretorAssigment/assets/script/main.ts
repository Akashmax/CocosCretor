

const { ccclass, property } = cc._decorator;

@ccclass
export default class main extends cc.Component {

    @property(cc.Node)
    HomePage: cc.Node = null;

    @property(cc.Node)
    GamePage: cc.Node = null;

    

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start() {

    }

    PlayBtn() {
        this.HomePage.active = false;
        this.GamePage.active = true;
    }

    Homenbtn() {
        cc.director.loadScene("Test");
    }

    // update (dt) {}
}
