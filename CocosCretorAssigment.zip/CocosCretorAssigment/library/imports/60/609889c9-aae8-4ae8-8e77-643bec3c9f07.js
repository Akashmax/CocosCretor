"use strict";
cc._RF.push(module, '60988nJquhK6I53ZDvsPJ8H', 'GameManger');
// script/GameManger.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameManger = /** @class */ (function (_super) {
    __extends(GameManger, _super);
    function GameManger() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.CardPrefabs = null;
        _this.GameScetion = null;
        _this.NextWrap = null;
        _this.PickColor = [];
        _this.MinNum = 0;
        _this.MaxNum = 0;
        _this.howmanyeachcard = 0;
        _this.BAckCArd = null;
        _this.Highlightimg = null;
        _this.blockTransp = null;
        _this.Leveltext = null;
        _this.LevelDone = null;
        _this.StoreAllCard = [];
        _this.NextCount = 1;
        _this.firstClick = null;
        _this.SecondClick = null;
        _this.callback = null;
        _this.FinalCountAllCard = 0;
        return _this;
    }
    GameManger_1 = GameManger;
    GameManger.prototype.onLoad = function () {
        GameManger_1.instance = this;
    };
    GameManger.prototype.start = function () {
        // this.PickColor = this.PickRandomColor();
        this.GetupCard();
        this.ShuffleArr(this.StoreAllCard);
        this.SetupCard();
    };
    GameManger.prototype.GetupCard = function () {
        var getrandom = this.PickThreeRandomNum();
        for (var i = 0; i < this.PickColor.length; i++) {
            for (var j = 0; j < this.howmanyeachcard; j++) {
                var card = cc.instantiate(this.CardPrefabs);
                card.children[2].getComponent(cc.Label).string = getrandom[i];
                card.children[1].getComponent(cc.Label).string = getrandom[i];
                card.children[0].color = this.PickColor[i];
                //  card.parent = this.GameScetion.children[i];
                card.setSiblingIndex(j);
                this.StoreAllCard.push(card);
            }
        }
    };
    GameManger.prototype.SetupCard = function () {
        var SequenceCount = 0;
        var PosY = 0;
        for (var i = 0; i < this.PickColor.length; i++) {
            PosY = 0;
            for (var j = 0; j < this.howmanyeachcard; j++) {
                this.StoreAllCard[SequenceCount].parent = this.GameScetion.children[i];
                this.StoreAllCard[SequenceCount].y = PosY;
                var cardbtn = this.StoreAllCard[SequenceCount].addComponent(cc.Button);
                cardbtn.getComponent(cc.Button).node.on("click", this.ClickCard, false);
                PosY -= 40;
                SequenceCount++;
            }
        }
        for (var k = 0; k < this.GameScetion.childrenCount; k++) {
            var cardparentbtn = this.GameScetion.children[k].addComponent(cc.Button);
            cardparentbtn.node.on("click", this.ClickCard, false);
        }
        GameManger_1.instance.lastBtnActive();
    };
    GameManger.prototype.ClickCard = function (event) {
        var curnode = event.node;
        if (GameManger_1.instance.firstClick != null && GameManger_1.instance.SecondClick == null) {
            GameManger_1.instance.SecondClick = curnode;
            var ChildCount = 0;
            var Getfirstindex = GameManger_1.instance.firstClick.parent.getSiblingIndex();
            var GetSecondindex = GameManger_1.instance.SecondClick.parent.getSiblingIndex();
            if (GameManger_1.instance.SecondClick.name == "Block" || GetSecondindex != Getfirstindex) {
                if (GameManger_1.instance.SecondClick.name == "Block") {
                    GameManger_1.instance.firstClick.parent = GameManger_1.instance.SecondClick;
                }
                else {
                    GameManger_1.instance.firstClick.parent = GameManger_1.instance.SecondClick.parent;
                    ChildCount = GameManger_1.instance.firstClick.parent.childrenCount;
                }
                var offsetY = (ChildCount == 0 ? 0 : (ChildCount - 1) * -40);
                GameManger_1.instance.MoveCard(GameManger_1.instance.firstClick, cc.v2(0, offsetY));
            }
            else {
                GameManger_1.instance.SecondClick = null;
            }
        }
        else {
            if (GameManger_1.instance.firstClick == null && curnode.name != "Block") {
                GameManger_1.instance.firstClick = curnode;
                GameManger_1.instance.firstClick.getComponent(cc.Sprite).spriteFrame = GameManger_1.instance.Highlightimg;
            }
        }
        clearTimeout(GameManger_1.instance.callback);
        GameManger_1.instance.lastBtnActive();
    };
    GameManger.prototype.MoveCard = function (currnode, secondnode) {
        GameManger_1.instance.firstClick.getComponent(cc.Sprite).spriteFrame = GameManger_1.instance.blockTransp;
        cc.tween(currnode)
            .to(0.2, { position: cc.v2(secondnode.x, secondnode.y) })
            .start();
        GameManger_1.instance.callback = function () {
            GameManger_1.instance.firstClick = null;
            GameManger_1.instance.SecondClick = null;
            GameManger_1.instance.MatchCard(currnode);
        };
        setTimeout(GameManger_1.instance.callback, 200);
    };
    GameManger.prototype.MatchCard = function (currnode) {
        var _this = this;
        if (currnode.parent.childrenCount < this.howmanyeachcard) {
            return;
        }
        var temp = [];
        for (var i = 0; i < currnode.parent.childrenCount; i++) {
            temp.push(parseInt(currnode.parent.children[i].children[1].getComponent(cc.Label).string));
        }
        var IsAllsamevalue = temp.every(function (a) { return a === temp[0]; });
        if (IsAllsamevalue) {
            var _loop_1 = function (i) {
                setTimeout(function () {
                    var flipnode = currnode.parent.children[i];
                    var tween = cc.tween(flipnode)
                        .to(0.5 * i, { y: flipnode.y < -1 ? flipnode.y + (i * 25) : 0, scaleX: -1 })
                        .start();
                    flipnode.children[3].active = true;
                    flipnode.removeComponent(cc.Button);
                    currnode.parent.removeComponent(cc.Button);
                }, (i * 100));
            };
            for (var i = 0; i < currnode.parent.childrenCount; i++) {
                _loop_1(i);
            }
            this.FinalCountAllCard++;
            this.scheduleOnce(function () {
                if (_this.FinalCountAllCard == _this.PickColor.length) {
                    _this.NextWrap.active = true;
                    _this.LevelDone.string = "LEVEL " + _this.NextCount + " COMPLETED";
                }
            }, 1.5);
        }
    };
    GameManger.prototype.HighLightCard = function (currnode) {
        cc.tween(currnode)
            .to(0.5, { position: cc.v2(currnode.x, currnode.y - 50), angle: 5 })
            .to(0.6, { scale: 1.1, angle: -5 })
            .to(0.5, { scale: 1, angle: 0 })
            .start();
    };
    GameManger.prototype.NextBtn = function () {
        this.NextCount++;
        this.Leveltext.string = "Level - " + this.NextCount;
        this.NextWrap.active = false;
        this.destroyCard();
        this.GetupCard();
        this.ShuffleArr(this.StoreAllCard);
        this.SetupCard();
    };
    GameManger.prototype.destroyCard = function () {
        //Destroy node
        for (var i = 0; i < this.GameScetion.childrenCount; i++) {
            if (this.GameScetion.children[i].childrenCount != 0) {
                for (var j = 0; j < this.GameScetion.children[i].childrenCount; j++) {
                    (this.GameScetion.children[i].children[j]).destroy();
                }
                this.GameScetion.children[i].removeAllChildren();
            }
        }
        //Reset value
        this.StoreAllCard = [];
        this.FinalCountAllCard = 0;
        this.callback = null;
        GameManger_1.instance.firstClick = null;
        GameManger_1.instance.SecondClick = null;
    };
    GameManger.prototype.lastBtnActive = function () {
        for (var i = 0; i < this.GameScetion.childrenCount; i++) {
            if (this.GameScetion.children[i].childrenCount != 0 && this.GameScetion.children[i].getComponent(cc.Button)) {
                this.GameScetion.children[i].getComponent(cc.Button).interactable = false;
                for (var j = 0; j < this.GameScetion.children[i].childrenCount; j++) {
                    if (j != this.GameScetion.children[i].childrenCount - 1) {
                        this.GameScetion.children[i].children[j].getComponent(cc.Button).interactable = false;
                    }
                    else {
                        this.GameScetion.children[i].children[j].getComponent(cc.Button).interactable = true;
                    }
                }
            }
            else {
                if (this.GameScetion.children[i].getComponent(cc.Button)) {
                    this.GameScetion.children[i].getComponent(cc.Button).interactable = true;
                }
            }
        }
    };
    GameManger.prototype.PickThreeRandomNum = function () {
        var rand = [];
        while (rand.length < this.PickColor.length) {
            var num = Math.floor(Math.random() * (this.MaxNum - this.MinNum) + this.MinNum);
            if (rand.indexOf(num) == -1) {
                rand.push(num);
            }
        }
        return rand;
    };
    GameManger.prototype.ShuffleArr = function (shuffled) {
        var _a;
        for (var i = shuffled.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * i + 1);
            _a = [shuffled[j], shuffled[i]], shuffled[i] = _a[0], shuffled[j] = _a[1];
        }
        return shuffled;
    };
    GameManger.prototype.PickRandomColor = function () {
        //Genrate three light color
        var pickcolor = [];
        for (var i = 0; i < this.PickColor.length; i++) {
            var Genratecolor = cc.color((1 + Math.random()) * 256 / 2, (1 + Math.random()) * 256 / 2, (1 + Math.random()) * 256 / 2);
            pickcolor.push(Genratecolor);
        }
        return pickcolor;
    };
    var GameManger_1;
    __decorate([
        property(cc.Prefab)
    ], GameManger.prototype, "CardPrefabs", void 0);
    __decorate([
        property(cc.Node)
    ], GameManger.prototype, "GameScetion", void 0);
    __decorate([
        property(cc.Node)
    ], GameManger.prototype, "NextWrap", void 0);
    __decorate([
        property(cc.Color)
    ], GameManger.prototype, "PickColor", void 0);
    __decorate([
        property(cc.Integer)
    ], GameManger.prototype, "MinNum", void 0);
    __decorate([
        property(cc.Integer)
    ], GameManger.prototype, "MaxNum", void 0);
    __decorate([
        property(cc.Integer)
    ], GameManger.prototype, "howmanyeachcard", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], GameManger.prototype, "BAckCArd", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], GameManger.prototype, "Highlightimg", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], GameManger.prototype, "blockTransp", void 0);
    __decorate([
        property(cc.Label)
    ], GameManger.prototype, "Leveltext", void 0);
    __decorate([
        property(cc.Label)
    ], GameManger.prototype, "LevelDone", void 0);
    GameManger = GameManger_1 = __decorate([
        ccclass
    ], GameManger);
    return GameManger;
}(cc.Component));
exports.default = GameManger;

cc._RF.pop();